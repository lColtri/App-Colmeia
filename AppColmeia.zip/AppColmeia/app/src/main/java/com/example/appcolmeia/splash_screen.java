package com.example.appcolmeia;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;

public class splash_screen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_screen);

        int tempoDeExibicao = 3000;         // Tempo em milissegundos (3 segundos)
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(splash_screen.this, MainActivity.class);
                startActivity(intent);
                finish();                   // Fecha a atividade atual, permitindo que o usuário volte para a tela de SplashScreen usando o botão "Back"
            }
        }, tempoDeExibicao);
    }
}

